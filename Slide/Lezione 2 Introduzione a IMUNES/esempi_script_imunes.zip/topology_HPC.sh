#!/bin/bash

sudo hcp etherspc1 pc1:/etc/ethers
sudo hcp etherspc2 pc2:/etc/ethers
sudo hcp etherspc3 pc3:/etc/ethers

sudo himage pc1 arp -f
sudo himage pc2 arp -f
sudo himage pc3 arp -f